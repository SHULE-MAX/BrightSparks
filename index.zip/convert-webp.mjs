import sharp from 'sharp';
import { readdir, stat, unlink } from 'fs/promises';
import { existsSync, readFileSync, writeFileSync } from 'fs';
import path from 'path';

const ROOT = new URL('.', import.meta.url).pathname.replace(/^\//, '');
const IMAGE_DIRS = [ROOT, path.join(ROOT, 'images/general'), path.join(ROOT, 'images/assets'), path.join(ROOT, 'images/news')];
const HTML_FILES = ['index.html','admissions.html','fees.html','careers.html','news.html','gallery.html','resources.html','calendar.html','demo.html'];
const EXTS = /\.(jpe?g|jfif|png)$/i;

let totalSaved = 0;
const renamed = [];

for (const dir of IMAGE_DIRS) {
  let entries;
  try { entries = await readdir(dir); } catch { continue; }

  for (const file of entries) {
    if (!EXTS.test(file)) continue;
    const inputPath  = path.join(dir, file);
    const outputName = file.replace(EXTS, '.webp');
    const outputPath = path.join(dir, outputName);
    const s = await stat(inputPath);

    const isPng = /\.png$/i.test(file);
    await sharp(inputPath)
      .webp({ quality: isPng ? 90 : 82, effort: 6 })
      .toFile(outputPath);

    const outStat = await stat(outputPath);
    const saved = s.size - outStat.size;
    totalSaved += saved;
    console.log(`✓  ${file.padEnd(35)} ${(s.size/1024).toFixed(0).padStart(6)} KB  →  ${(outStat.size/1024).toFixed(0).padStart(6)} KB  (${Math.round(saved/s.size*100)}% smaller)`);
    renamed.push({ old: file, new: outputName, dir });
  }
}

console.log(`\nTotal saved: ${(totalSaved/1024).toFixed(0)} KB\n`);

// Patch HTML files: replace all image src/href references
for (const htmlFile of HTML_FILES) {
  const fullPath = path.join(ROOT, htmlFile);
  if (!existsSync(fullPath)) continue;
  let html = readFileSync(fullPath, 'utf8');
  const before = html;

  // Replace all occurrences of image filenames with their .webp equivalents
  html = html.replace(/(['"(])((?:[^'"()]+\/)*[^'"()]+)\.(jpe?g|jfif|png)(['")])/gi, (match, open, base, ext, close) => {
    // Don't touch data URIs
    if (base.startsWith('data:')) return match;
    return `${open}${base}.webp${close}`;
  });

  if (html !== before) {
    writeFileSync(fullPath, html, 'utf8');
    console.log(`Updated HTML: ${htmlFile}`);
  }
}

// Also patch styles.css if it references any images
const cssPath = path.join(ROOT, 'styles.css');
if (existsSync(cssPath)) {
  let css = readFileSync(cssPath, 'utf8');
  const before = css;
  css = css.replace(/url\(['"]?([^'"()]+)\.(jpe?g|jfif|png)['"]?\)/gi, (m, base, ext) => {
    if (base.startsWith('data:')) return m;
    return `url('${base}.webp')`;
  });
  if (css !== before) {
    writeFileSync(cssPath, css, 'utf8');
    console.log('Updated styles.css');
  }
}

console.log('\nDone. You can now delete the original .jpg/.jpeg/.png/.jfif files.');
